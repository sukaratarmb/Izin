from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" MENU SSH ","ssh"),
Button.inline(" MENU VMESS ","vmess")],
[Button.inline(" MENU VLESS ","vless"),
Button.inline(" MENU TROJAN ","trojan")],
[Button.inline(" VPS INFO ","info"),
Button.inline(" SETTING ","setting")],
[Button.inline(" ‹ Back Menu › ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' cat /etc/xray/ssh | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/xray/config.json | grep "#vmg" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/xray/config.json | grep "#vlg" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/xray/config.json | grep "#trg" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		IPVPS=$(curl -s ipv4.icanhazip.com)
Exp=$(wget -qO- https://raw.githubusercontent.com/RMBL-ZERO/permission/main/ipmini | grep $IPVPS | cut -d ' ' -f 3)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")
data_ip="https://raw.githubusercontent.com/RMBL-ZERO/permission/main/ipmini"
d2=$(date -d "$date_list" +"+%s")
d1=$(date -d "$Exp" +"+%s")
dayleft=$(( ($d1 - $d2) / 86400 ))
echo "$dayleft" shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
✧◇───────────────────◇✧ 
      **💥⟨ 𝗕𝗼𝘁 𝗥𝗺𝗯𝗹 𝗩𝗽𝗻 𝗧𝘂𝗻𝗻𝗲𝗹 ⟩💥**
✧◇───────────────────◇✧ 
**»✨ OS     :** `{namaos.strip().replace('"','')}`
**»✨ CITY :** `{city.strip()}`
**»✨ DOMAIN :** `{DOMAIN}`
**»✨ IP VPS :** `{ipsaya.strip()}`
**»✨ EXP SC :** `{g.strip()} Day left`
✧◇───────────────────◇✧
            **💥⟨ 𝗧𝗼𝘁𝗮𝗹 𝘼𝙘𝙘𝙤𝙪𝙣𝙩 ⟩💥**
✧◇───────────────────◇✧
**»✨ SSH OVPN  :** `{ssh.strip()}` __account__
**»✨ XRAY VMESS  :** `{vms.strip()}` __account__
**»✨ XRAY VLESS  :** `{vls.strip()}` __account__
**»✨ XRAY TROJAN  :** `{trj.strip()}` __account__
**»🤖@Rmblvpn1**
✧◇───────────────────◇✧ 
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
